package com.emr.www.entity.patients;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "RegisterPatients")
public class RegisterPatients {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int no; // 환자 ID

    private String name;
    private String securityNum;
    private String gender;
    private String address;
    private String phone;
    private String email;
    private String bloodType;
    private float height;
    private float weight;
    private String allergies;
    private String bloodPressure;
    private double temperature;
    
	public int getNo() {
		return no;
	}
	
	public void setNo(int no) {
		this.no = no;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getSecurityNum() {
		return securityNum;
	}
	
	public void setSecurityNum(String securityNum) {
		this.securityNum = securityNum;
	}
	
	public String getGender() {
		return gender;
	}
	
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getBloodType() {
		return bloodType;
	}
	
	public void setBloodType(String bloodType) {
		this.bloodType = bloodType;
	}
	
	public float getHeight() {
		return height;
	}
	
	public void setHeight(float height) {
		this.height = height;
	}
	
	public float getWeight() {
		return weight;
	}
	
	public void setWeight(float weight) {
		this.weight = weight;
	}
	
	public String getAllergies() {
		return allergies;
	}
	
	public void setAllergies(String allergies) {
		this.allergies = allergies;
	}
	
	public String getBloodPressure() {
		return bloodPressure;
	}
	
	public void setBloodPressure(String bloodPressure) {
		this.bloodPressure = bloodPressure;
	}
	
	public double getTemperature() {
		return temperature;
	}
	
	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}
	
	public String getSmokingStatus() {
		return smokingStatus;
	}
	
	public void setSmokingStatus(String smokingStatus) {
		this.smokingStatus = smokingStatus;
	}
	private String smokingStatus;

    // Getters and Setters
}
