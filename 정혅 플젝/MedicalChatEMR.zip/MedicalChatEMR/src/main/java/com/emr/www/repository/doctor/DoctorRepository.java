package com.emr.www.repository.doctor;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.emr.www.entity.doctor.DoctorEntity;
import com.emr.www.entity.nurse.NurseEntity;

@Repository
public interface DoctorRepository extends JpaRepository<DoctorEntity, Integer>, JpaSpecificationExecutor<DoctorEntity> {
	//관리자 - 중복체크
	boolean existsBySecurityNum(String securityNum);

	//로그인 및 회원가입
	Optional<DoctorEntity> findByLicenseId(String licenseId);

	Optional<DoctorEntity> findByLicenseIdAndPassword(String licenseId, String password);
	
}
