package com.emr.MedicalChatEMR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalChatEmrApplicationTests {

	@Test
	void contextLoads() {
	}

}
