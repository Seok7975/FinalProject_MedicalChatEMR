package com.emr.www.entity.patient;

import java.time.LocalDateTime;

import com.emr.www.entity.doctor.DoctorEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class MedicalRecordEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "chart_num")
    private Long chartNum; // 차트 번호

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "patient_id", nullable = false)
    private PatientEntity patient; // 환자 ID

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "doc_id", nullable = false)
    private DoctorEntity doctor; // 진료 의사 ID

    @Column(name = "symptoms", columnDefinition = "TEXT")
    private String symptoms; // 증상

    @Column(name = "surgery_status", length = 1)
    private char surgeryStatus; // 수술 여부 ('Y' 또는 'N')

    @Column(name = "progress", columnDefinition = "TEXT")
    private String progress; // 경과

    @Column(name = "visit_date", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private LocalDateTime visitDate; // 진료 일자

    // Getters and Setters
    public Long getChartNum() {
        return chartNum;
    }

    public void setChartNum(Long chartNum) {
        this.chartNum = chartNum;
    }

    public PatientEntity getPatient() {
        return patient;
    }

    public void setPatient(PatientEntity patient) {
        this.patient = patient;
    }

    public DoctorEntity getDoctor() {
        return doctor;
    }

    public void setDoctor(DoctorEntity doctor) {
        this.doctor = doctor;
    }

    public String getSymptoms() {
        return symptoms;
    }

    public void setSymptoms(String symptoms) {
        this.symptoms = symptoms;
    }

    public char getSurgeryStatus() {
        return surgeryStatus;
    }

    public void setSurgeryStatus(char surgeryStatus) {
        this.surgeryStatus = surgeryStatus;
    }

    public String getProgress() {
        return progress;
    }

    public void setProgress(String progress) {
        this.progress = progress;
    }

    public LocalDateTime getVisitDate() {
        return visitDate;
    }

    public void setVisitDate(LocalDateTime visitDate) {
        this.visitDate = visitDate;
    }
}
