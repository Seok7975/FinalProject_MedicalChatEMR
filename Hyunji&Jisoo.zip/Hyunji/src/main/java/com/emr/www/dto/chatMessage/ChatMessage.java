package com.emr.www.dto.chatMessage;

public class ChatMessage {

}
//지수 구현 중 ..ㅎ