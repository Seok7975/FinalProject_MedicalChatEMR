package com.emr.www.dto.doctor;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DrugDTO {

	private int no;
	private int chartNum;
	private String cpntCd; //성분 코드
	private String ingdNameKor; //성분 명
	private String fomlNm; //제형명
	private String dosageRouteCode; //투여 경로
	private String dayMaxDosgQyUnit; //투여 단위
	private String dayMaxDosgQy; //1일 최대 투여량
}
