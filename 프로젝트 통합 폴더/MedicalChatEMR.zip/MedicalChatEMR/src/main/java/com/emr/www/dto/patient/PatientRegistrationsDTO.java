package com.emr.www.dto.patient;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PatientRegistrationsDTO {

	private int no;
	private String name;
	private String securityNum;
	private char gender;
	private String address;
	private String phone;
	private String email;
	private String bloodType;
	private float height;
	private float weight;
	private String allergies;
	private String bloodPressure;
	private float temperature;
	private char smokingStatus; // Y/N
	
	private List<MedicalRecordDTO> medicalRecords; // 환자의 진료 기록 리스트
}
