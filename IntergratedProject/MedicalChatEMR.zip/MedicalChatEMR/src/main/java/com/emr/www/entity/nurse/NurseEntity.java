package com.emr.www.entity.nurse;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "Nurse")
public class NurseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int no; // 간호사의 고유 식별자 (Primary Key)

	private String name; // 간호사의 이름
	private String securityNum; // 주민등록번호 (Unique Key)
	private String email; // 이메일 주소 (Unique Key)
	private String phone; // 전화번호
	private String licenseId; // 면허 ID (Unique Key)
	private String password; // 비밀번호 (암호화 저장 추천)
	private String position; // 직급
	private String departmentId; // 소속 진료과
	private String profileImage; // 프로필 이미지 경로
	private String activeStatus; // 활동 상태
}
