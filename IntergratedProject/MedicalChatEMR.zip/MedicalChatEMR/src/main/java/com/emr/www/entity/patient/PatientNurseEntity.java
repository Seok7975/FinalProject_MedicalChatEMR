package com.emr.www.entity.patient;

import java.time.LocalDate;

import com.emr.www.entity.nurse.NurseEntity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "PatientNurse")
public class PatientNurseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int no;

	@ManyToOne
	@JoinColumn(name = "patientId", referencedColumnName = "no")
	private PatientEntity patient;

	@ManyToOne
	@JoinColumn(name = "nurseId", referencedColumnName = "no")
	private NurseEntity nurse;

	private LocalDate relationshipStartDate;
	private LocalDate relationshipEndDate;
}
