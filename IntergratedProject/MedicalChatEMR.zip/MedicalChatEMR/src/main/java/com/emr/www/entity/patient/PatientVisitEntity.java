package com.emr.www.entity.patient;

import java.time.LocalDate;
import java.time.LocalTime;

import com.emr.www.entity.doctor.DoctorEntity;
import com.emr.www.entity.nurse.NurseEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

//환자 내원 테이블
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "PatientVisits")
public class PatientVisitEntity {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int no;

    private LocalDate visitDate;
    private LocalTime visitTime;
    private String patientName;
    
    @Column( unique = true)
    private String securityNum;  // 주민등록번호
    
    private String visitReason; // 내원 사유
    private String visitHistory;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "patientNo")
    private PatientRegistrationEntity patient;  // 환자 정보 (외래키)
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "doctorNo")
    private DoctorEntity doctor;  // 담당 의사 (외래키)
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "nurseNo")
    private NurseEntity nurse;  // 담당 간호사 (외래키)

}