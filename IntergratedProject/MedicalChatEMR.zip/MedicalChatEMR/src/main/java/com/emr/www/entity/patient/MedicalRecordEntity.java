package com.emr.www.entity.patient;

import java.time.LocalDateTime;

import com.emr.www.entity.doctor.DoctorEntity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "MedicalRecord")
public class MedicalRecordEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int chartNum;

    @ManyToOne
    @JoinColumn(name = "patientId", referencedColumnName = "no")
    private PatientEntity patient;

    @ManyToOne
    @JoinColumn(name = "docId", referencedColumnName = "no")
    private DoctorEntity doctor;

    private String symptoms;
    private String surgeryStatus;
    private String progress;
    private LocalDateTime visitDate;
}