package com.emr.www.entity.patient;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "PatientRegistrations")
public class PatientEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int no;
    private String name;
    
    @Column(unique = true)
    private String securityNum;
    
    private String gender;
    private String address;
    private String phone;
    private String email;
    private String bloodType;
    private float height;
    private float weight;
    private String allergies;
    private String bloodPressure;
    private double temperature;
    private String smokingStatus;
}
