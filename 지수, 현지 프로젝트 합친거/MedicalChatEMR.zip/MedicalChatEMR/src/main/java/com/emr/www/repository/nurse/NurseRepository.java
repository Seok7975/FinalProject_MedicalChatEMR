package com.emr.www.repository.nurse;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.emr.www.entity.nurse.NurseEntity;

@Repository
public interface NurseRepository extends JpaRepository<NurseEntity, Long>,JpaSpecificationExecutor<NurseEntity> {
    //관리자 
	boolean existsBySecurityNum(String securityNum);
	
	//로그인 및 회원가입
	Optional<NurseEntity> findByLicenseId(String licenseId);
    Optional<NurseEntity> findByLicenseIdAndPassword(String licenseId, String password);
}
