package com.emr.www.util.jwt;

import org.springframework.stereotype.Component;

//JWT 토큰을 생성하고, 검증하는 역할을 수행하는 유틸리티 클래스
@Component
public class JwtUtil {

}
