package com.emr.www.controller.employee;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.emr.www.repository.doctor.DoctorRepository;
import com.emr.www.repository.nurse.NurseRepository;
import com.emr.www.service.doctor.DoctorService;
import com.emr.www.service.employee.EmployeeService;
import com.emr.www.service.nurse.NurseService;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	public DoctorRepository doctorRepository;

	@Autowired
	public NurseRepository nurseRepository;

	@Autowired
	private DoctorService doctorService;

	@Autowired
	private NurseService nurseService;

	//로그인 메인 페이지
	@GetMapping("/loginMain")
	public String showLoginPage() {
		return "/login/LoginMain";
	}

	//로그인 회원 가입 페이지
	@GetMapping("/registration_form")
	public String showRegistrationForm() {
		return "/login/registration_form"; // src/main/webapp/WEB-INF/views/login/registration_form.jsp 로 렌더링
	}

	// 회원가입 처리
	@PostMapping("/signup")
	public String handleSignup(@RequestParam String licenseId, @RequestParam String password, RedirectAttributes redirectAttributes) {
		String result = employeeService.registerUser(licenseId, password);
		redirectAttributes.addFlashAttribute("message", result);
		return "redirect:/registration_form"; // 회원가입 창으로 돌아감 (등록 완료 후 닫힘 처리)
	}

	// 로그인 처리
	@PostMapping("/Login")
	public String login(@RequestParam String licenseId, @RequestParam String password, @RequestParam(required = false) boolean isAdmin,
			RedirectAttributes redirectAttributes) {
		String result = employeeService.validateUser(licenseId, password, isAdmin);

		if ("admin".equals(result)) {
			return "redirect:/admin/main";
		} else if ("doctor".equals(result)) {
			return "redirect:/doctor/main";
		} else if ("nurse".equals(result)) {
			return "redirect:/nurse/main";
		} else if ("head_nurse".equals(result)) {
			return "redirect:/headNurse/main";
		} else {
			redirectAttributes.addFlashAttribute("errorMessage", result);
			return "redirect:/loginMain"; // 리다이렉트 시 메시지 전달
		}
	}

	//비밀번호 찾기 페이지
	@GetMapping("/findPassword")
	public String showFindPasswordForm() {
		return "/login/findPassword"; // src/main/webapp/WEB-INF/views/login/findPassword.jsp 로 렌더링
	}

	//관리자 - 직원 검색
	@GetMapping("/searchEmployees")
	public List<Object> searchEmployees(@RequestParam(required = false) String name, @RequestParam(required = false) String job,
			@RequestParam(required = false) String position) {
		List<Object> employees = new ArrayList<>();

		if ("doctor".equalsIgnoreCase(job)) {
			employees.addAll(doctorService.searchDoctors(name, position));
		} else if ("nurse".equalsIgnoreCase(job)) {
			employees.addAll(nurseService.searchNurses(name, position));
		} else {
			// "전체" 또는 공백인 경우 의사와 간호사 모두 검색
			employees.addAll(doctorService.searchDoctors(name, position));
			employees.addAll(nurseService.searchNurses(name, position));
		}

		return employees;
	}

	//관리자 - 직원 조회
	@GetMapping("/getEmployees")
	@ResponseBody
	public List<Object> getEmployees() {
		// 모든 의사와 간호사를 가져옵니다.
		return employeeService.searchEmployees(null, null, null);
	}

	//직원 수정
	@PostMapping("/updateEmployee")
	@ResponseBody
	public ResponseEntity<String> updateEmployee(@RequestParam Long employeeNo, @RequestParam String name, @RequestParam String position,
			@RequestParam String phone, @RequestParam String email, @RequestParam String password, @RequestParam(required = false) String department,
			@RequestParam(required = false) String role) {
		try {
			employeeService.updateEmployee(employeeNo, name, position, phone, email, department, password);
			return ResponseEntity.ok("수정이 완료되었습니다.");
		} catch (Exception e) {
			return ResponseEntity.status(500).body("수정 중 오류가 발생했습니다.");
		}
	}

	//관리자 - 주민번호 유효성 체크
	@PostMapping("/checkDuplicateSSN")
	public ResponseEntity<Map<String, Boolean>> checkDuplicateSSN(@RequestBody Map<String, String> request) {
		String ssn = request.get("ssn");

		// EmployeeService를 통해 중복 체크 수행
		try {
			employeeService.checkSecurityNumDuplicate(ssn);
			// 중복이 없으면 false 반환
			Map<String, Boolean> response = new HashMap<>();
			response.put("duplicate", false);
			return ResponseEntity.ok(response);
		} catch (IllegalArgumentException e) {
			// 중복이 있을 경우 true 반환
			Map<String, Boolean> response = new HashMap<>();
			response.put("duplicate", true);
			return ResponseEntity.ok(response);
		}
	}

}
