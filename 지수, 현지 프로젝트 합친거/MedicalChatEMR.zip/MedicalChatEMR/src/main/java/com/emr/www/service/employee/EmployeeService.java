package com.emr.www.service.employee;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.emr.www.entity.admin.AdminEntity;
import com.emr.www.entity.doctor.DoctorEntity;
import com.emr.www.entity.nurse.NurseEntity;
import com.emr.www.repository.admin.AdminRepository;
import com.emr.www.repository.doctor.DoctorRepository;
import com.emr.www.repository.nurse.NurseRepository;

@Service
public class EmployeeService {

	@Autowired
	private DoctorRepository doctorRepository;

	@Autowired
	private NurseRepository nurseRepository;

	@Autowired
	private AdminRepository adminRepository;

	// 회원가입 처리
	public String registerUser(String licenseId, String password) {
		// 의사 라이센스 ID로 회원가입 처리
		Optional<DoctorEntity> doctorOpt = doctorRepository.findByLicenseId(licenseId);
		if (doctorOpt.isPresent()) {
			DoctorEntity doctor = doctorOpt.get();
			if (doctor.getPassword() != null) {
				return "이미 초기 비밀번호 설정이 완료되었습니다. 로그인을 진행해주세요.";
			}
			doctor.setPassword(password);
			doctorRepository.save(doctor);
			return "성공적으로 설정 되셨습니다. 로그인을 진행해주세요.";
		}

		Optional<NurseEntity> nurseOpt = nurseRepository.findByLicenseId(licenseId);
		if (nurseOpt.isPresent()) {
			NurseEntity nurse = nurseOpt.get();
			if (nurse.getPassword() != null) {
				return "이미 초기 비밀번호 설정이 완료되었습니다. 로그인을 진행해주세요.";
			}
			nurse.setPassword(password);
			nurseRepository.save(nurse);
			return "성공적으로 설정 되셨습니다. 로그인을 진행해주세요.";
		}

		return "승인되지 않은 ID입니다.";
	}

	// 로그인 처리
	public String validateUser(String licenseId, String password, boolean isAdmin) {
		if (isAdmin) {
			Optional<AdminEntity> adminOpt = adminRepository.findByAdminEmailAndPassword(licenseId, password);
			if (adminOpt.isPresent()) {
				return "admin";
			} else {
				return "관리자 이메일 또는 비밀번호가 잘못되었습니다.";
			}
		}

		Optional<DoctorEntity> doctorOpt = doctorRepository.findByLicenseId(licenseId);
		if (doctorOpt.isPresent()) {
			DoctorEntity doctor = doctorOpt.get();
			if (doctor.getPassword() == null) {
				return "회원가입을 통해 초기 비밀번호를 설정해주세요.";
			}
			if (!doctor.getPassword().equals(password)) {
				return "해당 계정의 ID와 PW를 다시 확인해주세요.";
			}
			return "doctor";
		}

		Optional<NurseEntity> nurseOpt = nurseRepository.findByLicenseId(licenseId);
		if (nurseOpt.isPresent()) {
			NurseEntity nurse = nurseOpt.get();
			if (nurse.getPassword() == null) {
				return "회원가입을 통해 초기 비밀번호를 설정해주세요.";
			}
			if (!nurse.getPassword().equals(password)) {
				return "해당 계정의 ID와 PW를 다시 확인해주세요.";
			}
			return "N".equals(nurse.getPosition()) ? "nurse" : "head_nurse";
		}

		return "해당 계정은 존재하지 않습니다.";
	}

	// 직원 검색 메서드, 이름(name), 직업군(job), 직급(position)을 기반으로 검색
	public List<Object> searchEmployees(String name, String job, String position) {
		List<Object> employees = new ArrayList<>();

		// 직업군에 따라 의사 또는 간호사를 검색하여 결과 리스트에 추가
		if ("doctor".equals(job)) {
			employees.addAll(findDoctorsByNameAndPosition(name, position));
		} else if ("nurse".equals(job)) {
			employees.addAll(findNursesByNameAndPosition(name, position));
		} else {
			// 직업군이 지정되지 않은 경우, 의사와 간호사 모두 검색하여 결과에 추가
			employees.addAll(findDoctorsByNameAndPosition(name, position));
			employees.addAll(findNursesByNameAndPosition(name, position));
		}

		return employees; // 최종적으로 검색된 직원 리스트를 반환
	}

	// 이름과 직급을 기준으로 의사를 검색하는 메서드
	private List<DoctorEntity> findDoctorsByNameAndPosition(String name, String position) {
		// Specification을 초기화 (null로 시작)
		Specification<DoctorEntity> spec = Specification.where(null);

		// 이름 조건이 있을 경우, LIKE 쿼리를 사용해 필터링
		if (name != null && !name.isEmpty()) {
			spec = spec.and((root, query, cb) -> cb.like(root.get("name"), "%" + name + "%"));
		}

		// 직급 조건이 있을 경우, EQUALS 쿼리를 사용해 필터링
		if (position != null && !position.isEmpty()) {
			spec = spec.and((root, query, cb) -> cb.equal(root.get("position"), position));
		}

		// 필터링된 결과 리스트 반환
		return doctorRepository.findAll(spec);
	}

	// 이름과 직급을 기준으로 간호사를 검색하는 메서드
	private List<NurseEntity> findNursesByNameAndPosition(String name, String position) {
		// Specification을 초기화 (null로 시작)
		Specification<NurseEntity> spec = Specification.where(null);

		// 이름 조건이 있을 경우, LIKE 쿼리를 사용해 필터링
		if (name != null && !name.isEmpty()) {
			spec = spec.and((root, query, cb) -> cb.like(root.get("name"), "%" + name + "%"));
		}

		// 직급 조건이 있을 경우, EQUALS 쿼리를 사용해 필터링
		if (position != null && !position.isEmpty()) {
			spec = spec.and((root, query, cb) -> cb.equal(root.get("position"), position));
		}

		// 필터링된 결과 리스트 반환
		return nurseRepository.findAll(spec);
	}

	// 직원 정보 수정 메서드, 직원 번호를 기준으로 해당 의사 또는 간호사 정보를 업데이트
	public void updateEmployee(Long employeeNo, String name, String position, String phone, String email, String department, String password) {
		if ("doctor".equals(position)) {
			// 의사인 경우, DoctorEntity를 가져와 수정 후 저장
			DoctorEntity doctor = doctorRepository.findById(employeeNo).orElseThrow(() -> new IllegalArgumentException("해당 의사가 없습니다."));
			doctor.setName(name);
			doctor.setPosition(position);
			doctor.setPhone(phone);
			doctor.setEmail(email);
			doctor.setDepartmentId(department);
			doctor.setPassword(password);
			doctorRepository.save(doctor);
		} else if ("nurse".equals(position)) {
			// 간호사인 경우, NurseEntity를 가져와 수정 후 저장
			NurseEntity nurse = nurseRepository.findById(employeeNo).orElseThrow(() -> new IllegalArgumentException("해당 간호사가 없습니다."));
			nurse.setName(name);
			nurse.setPosition(position);
			nurse.setPhone(phone);
			nurse.setEmail(email);
			nurse.setPassword(password);
			nurseRepository.save(nurse);
		}
	}

	// 주민등록번호 중복 체크 메서드, 의사와 간호사 모두의 중복 여부를 확인
	public void checkSecurityNumDuplicate(String securityNum) {
		boolean doctorExists = doctorRepository.existsBySecurityNum(securityNum); // 의사 중 중복 확인
		boolean nurseExists = nurseRepository.existsBySecurityNum(securityNum); // 간호사 중 중복 확인

		// 중복이 존재하면 예외를 발생시킴
		if (doctorExists || nurseExists) {
			throw new IllegalArgumentException("이미 사용 중인 주민등록번호입니다.");
		}
	}

}