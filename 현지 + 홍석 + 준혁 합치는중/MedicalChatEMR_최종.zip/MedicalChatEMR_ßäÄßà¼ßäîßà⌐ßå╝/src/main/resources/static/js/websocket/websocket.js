let stompClient = null;
let targetUserNo = null;
let targetUserRole = null;  // 채팅 대상의 역할을 저장하는 변수

// 세션 정보를 서버에서 가져오는 함수
function fetchSessionInfo() {
    $.get("/api/chat/get-session-info", function (data) {
        const userNo = data.userNo;
        const role = data.role;

        // 세션 정보를 전역 변수에 저장
        window.userNo = userNo;
        window.userRole = role;
    });
}

// 페이지 로드 시 세션 정보를 가져오도록 설정
$(document).ready(function () {
    fetchSessionInfo();
});

// WebSocket 연결 및 설정하는 함수
function connectWebSocket() {
    if (stompClient) {
        console.log("WebSocket is already connected.");
        return; // 이미 연결된 경우 추가 연결 시도를 방지
    }

    const socket = new SockJS('/ws'); // 서버의 WebSocket 엔드포인트 연결
    stompClient = Stomp.over(socket);

    // WebSocket 연결 및 상태 변경 메시지 수신 구독 설정
    stompClient.connect({}, function (frame) {
        console.log('Connected: ' + frame);

        // 상태 변경 메시지를 수신하는 구독 설정
        stompClient.subscribe('/topic/status', function (message) {
            const statusUpdate = JSON.parse(message.body);
            updateStatusUI(statusUpdate.no, statusUpdate.status); // 상태 UI 업데이트

            // 본인의 상태가 변경된 경우 직원 리스트 갱신
            if (statusUpdate.no == window.userNo) {
                fetchEmployeeList(); // 본인 상태를 포함한 전체 리스트 갱신
            }
        });

    }, function (error) {
        console.log('Connection error: ', error);
    });
}

// 알림 관련 설정
$(document).ready(function() {
    const notificationBtn = $('#notification-btn');
    const notificationBadge = $('#notification-badge');
    const notificationDropdown = $('#notification-dropdown-content');

    // 읽지 않은 알림을 가져오는 함수
    function fetchUnreadNotifications() {
        $.get('/api/chat/notifications/unread', function(data) { 
            notificationDropdown.empty();
            if (data.length > 0) {
                notificationBadge.text(data.length).show(); // 읽지 않은 알림 배지 표시
                data.forEach(notification => {
                    const notificationItem = $('<p>' + notification.message + '</p>');
                    notificationItem.click(function() {
                        markNotificationAsRead(notification.id); // 알림 읽음 처리
                    });
                    notificationDropdown.append(notificationItem);
                });
            } else {
                notificationBadge.hide(); // 읽지 않은 알림이 없으면 배지 숨김
                // 알림이 없을 경우 alert 창 띄우기
                alert('읽지 않은 알림이 없습니다.');
            }
        });
    }

    // 알림 읽음 처리 함수
    function markNotificationAsRead(notificationId) {
        $.post('/api/chat/notifications/read', { id: notificationId }, function() {
            fetchUnreadNotifications(); // 알림 목록 갱신
        });
    }

    // 알림 버튼 클릭 시 알림 목록 표시
    notificationBtn.click(function() {
        fetchUnreadNotifications();
    });

    // 페이지 로드 시 읽지 않은 알림 갯수 가져오기
    fetchUnreadNotifications();
});

// DOMContentLoaded 이벤트 핸들러
document.addEventListener('DOMContentLoaded', function() {
    const profileImage = document.getElementById('profile-image');
    const dropdownMenu = document.querySelector('.dropdown-menu');

    // 프로필 이미지를 클릭했을 때 드롭다운 메뉴 토글
    profileImage.addEventListener('click', function(event) {
        event.stopPropagation(); // 이벤트 버블링 방지
        dropdownMenu.style.display = (dropdownMenu.style.display == 'block') ? 'none' : 'block';
    });

    // 다른 영역을 클릭했을 때 드롭다운 메뉴를 닫음
    document.addEventListener('click', function(event) {
        if (!profileImage.contains(event.target) && !dropdownMenu.contains(event.target)) {
            dropdownMenu.style.display = 'none';
        }
    });

    // 페이지 로드 시 WebSocket 연결
    connectWebSocket();

    // Message 버튼 클릭 시 직원 리스트 모달 열기
    const messageButton = document.getElementById('messages-btn');
    const modal = document.getElementById('employee-list-modal');
    const closeModalButton = document.getElementById('close-modal-btn');

    if (messageButton) {
        messageButton.addEventListener('click', function () {
            fetchEmployeeList(); // 직원 리스트를 가져와 표시
            modal.style.display = 'block'; // 모달을 화면에 표시
        });
    }

    if (closeModalButton) {
        closeModalButton.addEventListener('click', function () {
            closeEmployeeList(); // 모달 닫기 함수 호출
        });
    }
});

// 상태 변경 시 서버에 상태 업데이트 요청
function setStatus(status, event) {
    if (event) {
        event.preventDefault(); // 기본 링크 동작 방지
    }

    console.log("Status change triggered:", status);

    fetch('/user/status', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: status }),
    })
    .then(response => response.text())
    .then(data => {
        console.log('Status updated successfully:', data);
        updateStatusUI(status); // 상태 UI 갱신
        fetchEmployeeList(); // 직원 리스트 갱신
    })
    .catch(error => {
        console.error('Status update failed:', error);
    });
}

// 상태 업데이트 시 UI를 갱신하는 함수
function updateStatusUI(newStatus) {
    const statusIndicatorDiv = document.querySelector('.status-indicator');
    if (statusIndicatorDiv) {
        const color = getStatusColor(newStatus); // 상태에 따른 색상 반환
        console.log('Setting status indicator color:', color, 'for status:', newStatus);
        statusIndicatorDiv.style.backgroundColor = color;
    }

    const statusLinks = document.querySelectorAll('.status-link');
    statusLinks.forEach(link => {
        const status = link.getAttribute('onclick').match(/'(\w+)'/)[1];
        const span = link.querySelector('.color-indicator');
        if (span) span.style.backgroundColor = getStatusColor(status); // 해당 상태에 맞는 색상 설정
        link.style.fontWeight = (status == newStatus) ? 'bold' : 'normal'; // 현재 상태 강조 표시
    });
}

// 상태에 따른 색상 반환 함수
function getStatusColor(status) {
    switch (status) {
        case 'away': return '#808080'; // 자리 비움
        case 'available': return '#008000'; // 진료 중
        case 'lunch': return '#FFA500'; // 점심시간
        default: return '#808080'; // 기본 색상
    }
}

// 채팅 모달을 여는 함수
function openChatModal(userNo, userName, userRole) {
    targetUserNo = userNo;
    targetUserRole = userRole;  // 채팅 대상의 역할 설정
    document.getElementById('chat-modal-title').textContent = `${userName} 님과의 채팅`;
    document.getElementById('chat-modal').style.display = 'block';

    // 채팅 대상에 대한 구독 설정
    subscribeToUserChat();

    // 메시지 보내기 함수 호출
    sendMessage();
}

// 채팅 모달을 닫는 함수
function closeChatModal() {
    document.getElementById('chat-modal').style.display = 'none';
    targetUserNo = null;
    targetUserRole = null;
    if (stompClient) stompClient.disconnect(); // WebSocket 연결 종료
}

// WebSocket을 통해 특정 사용자의 채팅 메시지 수신 구독 설정
function connectToChatWebSocket() {
    if (stompClient && targetUserNo) {
        stompClient.subscribe(`/queue/chat/${targetUserNo}`, function (message) {
            const receivedMessage = JSON.parse(message.body);
            displayMessage(receivedMessage); // 받은 메시지 표시
        });
    }
}

// 메시지를 보내는 함수
function sendMessage() {
    const messageInput = document.getElementById('chat-input');
    const messageContent = messageInput.value.trim();

    if (messageContent && stompClient) {
        const chatMessage = {
            senderNo: window.userNo, // 세션에서 가져온 사용자 번호 활용
            senderType: window.userRole, // 세션에서 가져온 사용자 유형 활용
            recipientNo: targetUserNo, // 대상 사용자 번호
            recipientType: targetUserRole, // 대상 사용자 유형
            content: messageContent, // 메시지 내용
            timestamp: new Date().toISOString() // 메시지 전송 시간
        };

        // WebSocket을 통해 메시지 전송 및 서버에 저장
        stompClient.send("/api/chat/send", {}, JSON.stringify(chatMessage)); 
        
        // 서버에 메시지 저장
        $.post('/api/chat/save', chatMessage, function(response) {
            console.log('Message saved:', response);
        }).fail(function(error) {
            console.error('Failed to save message:', error);
        });

        messageInput.value = ''; // 입력 필드 초기화
        displayMessage(chatMessage); // 보낸 메시지 표시
    }
}

// 메시지를 채팅 창에 표시하는 함수
function displayMessage(message) {
    const chatMessagesDiv = document.getElementById('chat-messages');
    const messageElement = document.createElement('div');
    messageElement.textContent = `${message.senderNo}: ${message.content}`;
    chatMessagesDiv.appendChild(messageElement);
    chatMessagesDiv.scrollTop = chatMessagesDiv.scrollHeight; // 스크롤을 가장 아래로
}

// 알림을 화면에 표시하는 함수 (예: 새 메시지 도착 시)
function displayNotification(message) {
    alert(`${message.senderNo}: ${message.content}`); // 간단한 알림 예시
}

// 직원 리스트 모달을 닫는 함수
function closeEmployeeList() {
    const modal = document.getElementById('employee-list-modal');
    modal.style.display = 'none';
}

// 직원 리스트를 가져오는 함수
function fetchEmployeeList() {
    $.get('/user/statuses', function (data) { 
        const employees = data.map(employee => ({
            no: employee.no,
            name: employee.name,
            role: employee.role,
            status: employee.status
        }));
        renderEmployeeList(employees); // 직원 리스트 렌더링
    });
}

// 직원 리스트를 화면에 렌더링하는 함수
function renderEmployeeList(employees) {
    const employeeListElement = document.getElementById('employee-list');
    employeeListElement.innerHTML = ''; // 기존 리스트 초기화

    employees.forEach(employee => {
        const listItem = document.createElement('li');
        listItem.id = `employee-${employee.no}`;

        const link = document.createElement('a');
        link.href = "#";
        link.textContent = `${employee.name} <${employee.role}> `;
        link.onclick = function () {
            openChatModal(employee.no, employee.name, employee.role); // 채팅 모달 열기
        };

        const statusSpan = document.createElement('span');
        statusSpan.classList.add('status');
        statusSpan.textContent = `[${getStatusLabel(employee.status)}]`;

        link.appendChild(statusSpan);
        listItem.appendChild(link);
        listItem.style.color = getStatusColor(employee.status);
        employeeListElement.appendChild(listItem);
    });
}

// 상태에 따른 라벨 반환 함수
function getStatusLabel(status) {
    switch (status) {
        case 'away': return '자리 비움';
        case 'available': return '진료 중';
        case 'lunch': return '점심시간';
        default: return '미확인';
    }
}

// 사용자의 채팅 메시지 수신을 구독하는 함수
function subscribeToUserChat() {
    if (stompClient && targetUserNo) {
        stompClient.subscribe(`/queue/chat/${targetUserNo}`, function (message) {
            const receivedMessage = JSON.parse(message.body);
            displayMessage(receivedMessage); // 받은 메시지 표시
        });
    }
}
