package com.emr.www.config.webSocket;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.messaging.SessionConnectedEvent;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;

import com.emr.www.service.redis.UserStatusService;

@Component
public class WebSocketEventListener {

    @Autowired
    private UserStatusService userStatusService;

    @EventListener
    public void handleWebSocketConnectListener(SessionConnectedEvent event) {
        StompHeaderAccessor headerAccessor = StompHeaderAccessor.wrap(event.getMessage());

        // 세션 속성이 null일 경우 처리
        if (headerAccessor.getSessionAttributes() == null) {
            System.err.println("Session attributes are null during WebSocket connection");
            return;
        }

        Integer no = (Integer) headerAccessor.getSessionAttributes().get("no");

        if (no != null && no > 0) { // 기본값이 아닌 경우에만 처리
            userStatusService.updateStatus(no, "online");
        }
    }

    @EventListener
    public void handleWebSocketDisconnectListener(SessionDisconnectEvent event) {
        StompHeaderAccessor headerAccessor = StompHeaderAccessor.wrap(event.getMessage());

        // 세션 속성이 null일 경우 처리
        if (headerAccessor.getSessionAttributes() == null) {
            System.err.println("Session attributes are null during WebSocket disconnection");
            return;
        }

        Integer no = (Integer) headerAccessor.getSessionAttributes().get("no");

        if (no != null && no > 0) { // 기본값이 아닌 경우에만 처리
            userStatusService.updateStatus(no, "offline");
        }
    }
}
