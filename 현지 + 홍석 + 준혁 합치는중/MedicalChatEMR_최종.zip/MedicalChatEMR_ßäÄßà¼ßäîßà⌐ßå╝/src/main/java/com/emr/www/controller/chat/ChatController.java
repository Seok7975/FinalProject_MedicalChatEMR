package com.emr.www.controller.chat;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.emr.www.dto.chat.ChatMessageDTO;
import com.emr.www.service.chat.ChatMessageService;

import jakarta.servlet.http.HttpSession;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/chat")
public class ChatController {

	@Autowired
    private ChatMessageService chatMessageService;

    @PostMapping("/save")
   public ResponseEntity<ChatMessageDTO> saveMessage(@RequestBody ChatMessageDTO chatMessageDTO) {
        ChatMessageDTO savedMessage = chatMessageService.saveMessage(chatMessageDTO);
        return ResponseEntity.ok(savedMessage);
    }

    
    @GetMapping("/messages")
    public List<ChatMessageDTO> getMessagesBetweenUsers(
            @RequestParam Integer senderNo, 
            @RequestParam String senderType, 
            @RequestParam Integer recipientNo, 
            @RequestParam String recipientType) { // recipientType 추가
        return chatMessageService.getMessagesBetweenUsers(senderNo, senderType, recipientNo, recipientType);
    }

    @PostMapping("/notifications/read")
    public void markMessageAsRead(@RequestParam Long messageId) {
        chatMessageService.markAsRead(messageId);
    }
    
    @GetMapping("/get-session-info")
    public ResponseEntity<Map<String, Object>> getSessionInfo(HttpSession session) {
        Integer userNo = (Integer) session.getAttribute("userNo");
        String role = (String) session.getAttribute("role");

        Map<String, Object> sessionInfo = new HashMap<>();
        sessionInfo.put("userNo", userNo);
        sessionInfo.put("role", role);

        return ResponseEntity.ok(sessionInfo);
    }
    
    /**
     * 사용자가 받은 읽지 않은 메시지를 조회합니다.
     *
     * @param session HTTP 세션 객체
     * @return 읽지 않은 메시지 목록
     */
    @GetMapping("/notifications/unread")
    public ResponseEntity<List<ChatMessageDTO>> getUnreadNotifications(HttpSession session) {
        Integer recipientNo = (Integer) session.getAttribute("userNo");
        String recipientType = (String) session.getAttribute("role");

        if (recipientNo == null || recipientType == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        List<ChatMessageDTO> unreadMessages = chatMessageService.getUnreadMessages(recipientNo, recipientType);
        return ResponseEntity.ok(unreadMessages);
    }
}