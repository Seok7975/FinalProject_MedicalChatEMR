package com.emr.www.config.jwt;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

	private final JwtAuthenticationFilter jwtAuthenticationFilter;

	public SecurityConfig(JwtAuthenticationFilter jwtAuthenticationFilter) {
		this.jwtAuthenticationFilter = jwtAuthenticationFilter;
	}

	@Bean
	protected SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		// CORS 설정 비활성화
		http.cors(cors -> cors.disable()) // CORS 설정을 비활성화합니다.

				// CSRF 보호를 비활성화합니다.
				.csrf(csrf -> csrf.disable());

		// 특정 경로에 대해 CSRF 보호를 비활성화
		http.csrf(csrf -> csrf.ignoringRequestMatchers("/ws/**", // 웹소켓 경로에 대해 CSRF 비활성화
				"/css/**", "/js/**","/api", "/img/**", "/images/**","/websocket/**","/api/chat/notifications/**","topic/**","user/**","/app/**", // 정적 리소스에 대해 CSRF 비활성화
				"/loginMain", "/signup", "/registration_form", "/Login", "/inactivity-logout", "/logout","/favicon.ico","/queue/**","/api/chat/**" // 인증이 필요 없는
																											// 페이지들에 대해
																											// CSRF 비활성화
		));

		// 세션 비활성화 (JWT 기반 인증으로 상태 없는 방식 사용)
		http.sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS));

		// 세션 고정 공격 방지 설정을 비활성화 (세션을 사용하지 않으므로 필요 없음)
		// http.sessionManagement(session ->
		// session.sessionFixation().migrateSession());

		// URL 접근 제어 설정
		http.authorizeHttpRequests(auth -> auth.requestMatchers("/ws/**").permitAll() // 웹소켓 경로를 인증 없이 허용
				.requestMatchers("/css/**", "/js/**", "/img/**", "/images/**").permitAll() // 정적 리소스에 대한 접근 허용
				.requestMatchers("/loginMain", "/signup","/api/chat/notifications/** ", "/api/chat/**", "/registration_form", "/Login", "/inactivity-logout",
						"/logout","/user/**","/favicon.ico","topic/**","/queue/**","/app/**").permitAll() // 로그인, 회원가입 페이지 및 리소스는 누구나 접근 가능
				.requestMatchers("/WEB-INF/views/login/**").permitAll() // WEB-INF 내부의 로그인 페이지에 대한 모든 접근 허용
				.requestMatchers("/WEB-INF/views/admin/**").hasRole("ADMIN") // 관리자 JSP 페이지에 관리자만 접근 허용
				.requestMatchers("/WEB-INF/views/doctor/**").hasRole("DOCTOR") // 의사 JSP 페이지에 의사만 접근 허용
				.requestMatchers("/WEB-INF/views/headNurse/**").hasRole("H") // 수간호사 JSP 페이지에 수간호사만 접근 허용
				.requestMatchers("/WEB-INF/views/nurse/**").hasRole("N") // 간호사 JSP 페이지에 간호사만 접근 허용
				.requestMatchers("/admin/**").hasRole("ADMIN") // 관리자만 접근 허용
				.requestMatchers("/doctor/**", "/api/doctor/**", "/dicom/**").hasRole("DOCTOR") // 의사만 접근 허용
				.requestMatchers("/api/doctor/**").hasRole("DOCTOR") // 의사만 API 접근 가능
				.requestMatchers("/nurse/**").hasRole("N") // 간호사만 접근 허용
				.requestMatchers("/headNurse/**").hasRole("H") // 수간호사만 접근 허용
				.requestMatchers("/api/patients/**").authenticated() // 인증된 사용자 누구나 접근 가능
				.anyRequest().authenticated() // 나머지 요청도 인증된 사용자만 접근 가능하게 설정
		);
		/* CSRF 비활성화 경로 추가: "/ws/**" 경로에 대해 CSRF 보호를 비활성화했습니다. 이로 인해 WebSocket 연결 시 CSRF 오류가 발생하지 않도록 했습니다.
WebSocket 접근 허용: "/ws/**" 경로에 대해 인증 없이 접근할 수 있도록 설정했습니다.
정적 리소스 및 공개 페이지 접근 허용: /css/**, /js/**, /img/**, /images/** 등 정적 리소스와 로그인, 회원가입 페이지 등에 대한 접근을 인증 없이 허용했습니다.
기타 URL 접근 제어: 관리자, 의사, 간호사, 수간호사 역할에 맞게 JSP 페이지와 API 접근을 제한했습니다. */

		// JWT 필터를 UsernamePasswordAuthenticationFilter 앞에 추가
		http.addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

		// 로그아웃 설정
		http.logout(logout -> logout.logoutUrl("/logout") // 로그아웃 URL 설정
				.invalidateHttpSession(true) // 세션 무효화
				.deleteCookies("JSESSIONID", "jwtToken") // 쿠키 삭제
				.logoutSuccessUrl("/loginMain") // 로그아웃 후 리디렉트
		);

		return http.build();
	}

	@Bean
	protected HttpSessionEventPublisher httpSessionEventPublisher() {
		return new HttpSessionEventPublisher();
	}
	public WebMvcConfigurer corsConfigurer() {
	    return new WebMvcConfigurer() {
	    	 @Override
	    	    public void addCorsMappings(CorsRegistry registry) {
	    	        registry.addMapping("/**")
	    	                .allowedOrigins("http://localhost:8080") // 클라이언트 도메인 추가
	    	                .allowedMethods("GET", "POST", "PUT", "DELETE")
	    	                .allowedHeaders("*")
	    	                .allowCredentials(true);
	    	    }
	    };
	}
}
