package com.emr.www.config.redis;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;


import com.emr.www.entity.chat.ChatMessageEntity;

@Configuration
public class RedisConfig {

    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory) {
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(redisConnectionFactory);

        // Key를 위한 Serializer
        template.setKeySerializer(new StringRedisSerializer());

        // Value를 위한 Serializer
        template.setValueSerializer(new GenericJackson2JsonRedisSerializer());

        return template;
    }

    @Bean
    public RedisTemplate<String, ChatMessageEntity> chatMessageRedisTemplate(RedisConnectionFactory redisConnectionFactory) {
        RedisTemplate<String, ChatMessageEntity> template = new RedisTemplate<>();
        template.setConnectionFactory(redisConnectionFactory);

        // Key를 위한 Serializer
        template.setKeySerializer(new StringRedisSerializer());

        // Value를 위한 Serializer
        template.setValueSerializer(new GenericJackson2JsonRedisSerializer());

        return template;
    }
}
