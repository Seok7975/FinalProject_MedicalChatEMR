package com.emr.www.service.chat;

import com.emr.www.dto.chat.ChatMessageDTO;
import com.emr.www.entity.chat.ChatMessageEntity;
import com.emr.www.repository.admin.AdminRepository;
import com.emr.www.repository.chat.ChatMessageRepository;
import com.emr.www.repository.doctor.DoctorRepository;
import com.emr.www.repository.nurse.NurseRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Service
public class ChatMessageService {

    @Autowired
    private ChatMessageRepository chatMessageRepository;

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;
    
    @Autowired
    private RedisTemplate<String, ChatMessageEntity> chatMessageRedisTemplate;
    
    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private NurseRepository nurseRepository;

    private static final String USER_DATA_KEY = "USER_DATA";
    private static final String MESSAGE_KEY_PREFIX = "CHAT_MESSAGE_";

    /**
     * 사용자 번호를 통해 이름을 가져옵니다.
     * Redis에 캐싱된 이름이 없다면 DB에서 조회 후 캐싱합니다.
     *
     * @param userNo 사용자 번호
     * @return 사용자 이름
     */
    public String getUserNameByNo(Integer userNo) {
        String name = (String) redisTemplate.opsForHash().get(USER_DATA_KEY, userNo);

        if (name == null) {
            if (adminRepository.existsById(userNo)) {
                name = "관리자";
            } else if (doctorRepository.existsById(userNo)) {
                name = doctorRepository.findById(userNo)
                            .map(doctor -> doctor.getName())
                            .orElse("Unknown Doctor");
            } else if (nurseRepository.existsById(userNo)) {
                name = nurseRepository.findById(userNo)
                            .map(nurse -> nurse.getName())
                            .orElse("Unknown Nurse");
            } else {
                name = "Unknown User";
            }

            if (!name.startsWith("Unknown")) {
                redisTemplate.opsForHash().put(USER_DATA_KEY, userNo, name);
                redisTemplate.expire(USER_DATA_KEY, 1, TimeUnit.DAYS);
            }
        }

        return name;
    }

    /**
     * 특정 사용자가 받은 읽지 않은 메시지의 개수를 반환합니다.
     * @param recipientNo 수신자의 번호
     * @param recipientType 수신자의 유형 (예: "DOCTOR", "NURSE")
     * @return 읽지 않은 메시지 개수와 내용을 포함한 List
     */
    public List<ChatMessageDTO> getUnreadMessages(Integer recipientNo, String recipientType) {
        List<ChatMessageEntity> unreadMessages = chatMessageRepository.findByRecipientNoAndRecipientTypeAndIsReadFalse(recipientNo, recipientType);
        return unreadMessages.stream().map(this::convertEntityToDTO).collect(Collectors.toList());
    }
    
    /**
     * 메시지를 저장하고, Redis에 캐싱하고, 수신자가 읽지 않은 메시지가 있을 경우 알림을 전송합니다.
     *
     * @param chatMessageDTO 저장할 메시지 정보
     * @return 저장된 메시지의 DTO
     */
    public ChatMessageDTO saveMessage(ChatMessageDTO chatMessageDTO) {
        ChatMessageEntity chatMessage = new ChatMessageEntity();
        chatMessage.setSenderNo(chatMessageDTO.getSenderNo());
        chatMessage.setSenderType(chatMessageDTO.getSenderType());
        chatMessage.setRecipientNo(chatMessageDTO.getRecipientNo());
        chatMessage.setRecipientType(chatMessageDTO.getRecipientType());
        chatMessage.setContent(chatMessageDTO.getContent());
        chatMessage.setIsRead(false);
        chatMessage.setTimestamp(chatMessageDTO.getTimestamp());

        chatMessage = chatMessageRepository.save(chatMessage);

        // Redis에 메시지 캐싱
        String redisKey = MESSAGE_KEY_PREFIX + chatMessage.getNo();
        redisTemplate.opsForValue().set(redisKey, chatMessage, 1, TimeUnit.DAYS);

        sendUnreadMessageNotification(chatMessageDTO.getRecipientNo(), chatMessageDTO.getRecipientType());

        return convertEntityToDTO(chatMessage);
    }

    /**
     * 특정 발신자와 수신자 간의 모든 메시지를 시간순으로 조회합니다.
     * Redis에 캐싱된 메시지가 있다면 이를 먼저 반환하고, 없을 경우 데이터베이스에서 조회합니다.
     *
     * @param senderNo 발신자의 번호
     * @param senderType 발신자의 유형 (예: 'DOCTOR', 'NURSE')
     * @param recipientNo 수신자의 번호
     * @param recipientType 수신자의 유형 (예: 'DOCTOR', 'NURSE')
     * @return 조회된 메시지의 DTO 목록
     */
    public List<ChatMessageDTO> getMessagesBetweenUsers(Integer senderNo, String senderType, Integer recipientNo, String recipientType) {
        // Redis에서 캐싱된 메시지 조회
        String redisKey = MESSAGE_KEY_PREFIX + senderNo + "_" + recipientNo;
        List<ChatMessageEntity> cachedMessages = (List<ChatMessageEntity>) chatMessageRedisTemplate.opsForValue().get(redisKey);

        if (cachedMessages != null) {
            return cachedMessages.stream().map(this::convertEntityToDTO).collect(Collectors.toList());
        } else {
            List<ChatMessageEntity> messages = chatMessageRepository.findMessages(senderNo, senderType, recipientNo, recipientType);
            redisTemplate.opsForValue().set(redisKey, messages, 1, TimeUnit.DAYS);
            return messages.stream().map(this::convertEntityToDTO).collect(Collectors.toList());
        }
    }

    /**
     * 메시지를 읽음 상태로 변경합니다.
     *
     * @param messageId 읽음 처리할 메시지의 ID
     */
    public void markAsRead(Long messageId) {
        Optional<ChatMessageEntity> chatMessageOpt = chatMessageRepository.findById(messageId);
        if (chatMessageOpt.isPresent()) {
            ChatMessageEntity chatMessage = chatMessageOpt.get();
            chatMessage.setIsRead(true);
            chatMessageRepository.save(chatMessage);

            // Redis에서 해당 메시지 캐싱된 정보 업데이트
            String redisKey = MESSAGE_KEY_PREFIX + messageId;
            redisTemplate.opsForValue().set(redisKey, chatMessage, 1, TimeUnit.DAYS);
        }
    }

    /**
     * 수신자의 읽지 않은 메시지에 대한 알림을 WebSocket을 통해 전송합니다.
     *
     * @param recipientNo 수신자의 번호
     * @param recipientType 수신자의 유형
     */
    public void sendUnreadMessageNotification(Integer recipientNo, String recipientType) {
        List<ChatMessageEntity> unreadMessages = chatMessageRepository.findByRecipientNoAndRecipientTypeAndIsReadFalse(recipientNo, recipientType);

        if (!unreadMessages.isEmpty()) {
            String notificationMessage = "You have " + unreadMessages.size() + " unread messages.";
            messagingTemplate.convertAndSendToUser(recipientNo.toString(), "/queue/notifications", notificationMessage);
        }
    }

    /**
     * ChatMessageEntity를 ChatMessageDTO로 변환합니다.
     *
     * @param entity 변환할 Entity
     * @return 변환된 DTO
     */
    public ChatMessageDTO convertEntityToDTO(ChatMessageEntity entity) {
        String senderName = getUserNameByNo(entity.getSenderNo());
        String recipientName = getUserNameByNo(entity.getRecipientNo());
        
        return new ChatMessageDTO(
            entity.getNo(),
            entity.getSenderNo(),
            senderName,
            entity.getSenderType(),
            entity.getRecipientNo(),
            recipientName,
            entity.getRecipientType(),
            entity.getContent(),
            entity.getIsRead(),
            entity.getTimestamp()
        );
    }
}
