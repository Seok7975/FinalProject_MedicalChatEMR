package com.emr.www.controller.redis;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.emr.www.dto.redis.UserWithStatusDto;
import com.emr.www.service.redis.UserStatusService;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserStatusService userStatusService;

//    // 사용자가 로그인 시 상태를 가져옴
//    @GetMapping("/status")
//    public String getStatus(@RequestParam int no) {
//        return userStatusService.getStatus(no);
//    }

    // 상태 업데이트 API
    @PostMapping("/status")
    public ResponseEntity<?> StatusUpdate(@RequestBody Map<String, Object> statusUpdate, HttpSession session) {
        Integer userNo = (Integer) session.getAttribute("userNo");

        if (userNo == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not authenticated");
        }

        String status = (String)statusUpdate.get("status");

        // 이제 userNo와 status를 사용해 비즈니스 로직을 처리합니다.
        userStatusService.updateStatus(userNo, status);

        return ResponseEntity.ok("Status updated successfully");
    }
    @PostMapping("/set-session-info")
    public void setSessionInfo(HttpSession session, @RequestParam String userNo, @RequestParam String role) {
        session.setAttribute("userNo", userNo);
        session.setAttribute("role", role);
    }

    // WebSocket을 통한 상태 전파
    @MessageMapping("/ws/status")  // 경로를 /ws/status로 변경
    @SendTo("/topic/status")
    public String broadcastStatus(String statusMessage) {
        return statusMessage;
    }
    
 // 전체 직원 리스트를 반환
    @GetMapping("/statuses")
    public List<UserWithStatusDto> getAllUserStatuses() {
        return userStatusService.searchemployeeall();
    }
}
