package com.emr.www.dto.chat;

import java.time.LocalDateTime;

public class ChatMessageDTO {
    private Long no; 
    private Integer senderNo;
    private String senderName;
    private String senderType;
    private Integer recipientNo;
    private String recipientName;
    private String recipientType;
    private String content;
    private boolean isRead;
    private LocalDateTime timestamp;

    // Constructor with all fields
    public ChatMessageDTO(Long no, Integer senderNo, String senderName, String senderType, Integer recipientNo, String recipientName, String recipientType, String content, boolean isRead, LocalDateTime timestamp) {
        this.no = no;
        this.senderNo = senderNo;
        this.senderName = senderName;
        this.senderType = senderType;
        this.recipientNo = recipientNo;
        this.recipientName = recipientName;
        this.recipientType = recipientType;
        this.content = content;
        this.isRead = isRead;
        this.timestamp = timestamp;
    }

    // Getters and setters (optional, if you need them)
    public Long getNo() { return no; }
    public void setNo(Long no) { this.no = no; }

    public Integer getSenderNo() { return senderNo; }
    public void setSenderNo(Integer senderNo) { this.senderNo = senderNo; }

    public String getSenderName() { return senderName; }
    public void setSenderName(String senderName) { this.senderName = senderName; }

    public String getSenderType() { return senderType; }
    public void setSenderType(String senderType) { this.senderType = senderType; }

    public Integer getRecipientNo() { return recipientNo; }
    public void setRecipientNo(Integer recipientNo) { this.recipientNo = recipientNo; }

    public String getRecipientName() { return recipientName; }
    public void setRecipientName(String recipientName) { this.recipientName = recipientName; }

    public String getRecipientType() { return recipientType; }
    public void setRecipientType(String recipientType) { this.recipientType = recipientType; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public boolean getIsRead() { return isRead; }
    public void setIsRead(boolean isRead) { this.isRead = isRead; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
}
