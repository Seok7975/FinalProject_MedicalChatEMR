package com.emr.www.service.redis;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import com.emr.www.dto.redis.UserWithStatusDto;
import com.emr.www.entity.nurse.NurseEntity;
import com.emr.www.entity.doctor.DoctorEntity;
import com.emr.www.repository.doctor.DoctorRepository;
import com.emr.www.repository.nurse.NurseRepository;

@Service
public class UserStatusService {

    @Autowired
    private RedisTemplate <String, Object> redisTemplate;

    @Autowired
    private DoctorRepository doctorRepository; // 의사 정보 접근을 위한 Repository

    @Autowired
    private NurseRepository nurseRepository; // 간호사 정보 접근을 위한 Repository

    private static final String STATUS_KEY_PREFIX = "user_status:"; // 사용자 상태 키의 접두사

    /**
     * 모든 사용자의 상태 정보를 가져오고, 사용자 정보를 DB에서 조회하여 결합.
     * @return List<UserWithStatusDto> - 사용자 상태와 관련된 정보를 포함한 DTO 리스트
     */
    public List<UserWithStatusDto> getAllUserStatuses() {
        // Redis에서 모든 사용자 상태 키 가져오기
        Set<String> keys = redisTemplate.keys(STATUS_KEY_PREFIX + "*");

        // 각 키에서 상태를 가져오고, JPA를 통해 DB에서 사용자 정보를 조회하여 결합
        return keys.stream().map(key -> {
            // Redis 키에서 접두사를 제거하고 사용자 No를 추출
            int no = Integer.parseInt(key.replace(STATUS_KEY_PREFIX, ""));
            // Redis에서 해당 사용자 No에 대한 상태 값 가져오기
            String status = (String)redisTemplate.opsForValue().get(key);

            // 의사 정보 조회
            DoctorEntity doctor = doctorRepository.findById(no).orElse(null);
            if (doctor != null) {
                return new UserWithStatusDto(no, doctor.getName(), "DOCTOR", status);
            }

            // 간호사 정보 조회
            NurseEntity nurse = nurseRepository.findById(no).orElse(null);
            if (nurse != null) {
                return new UserWithStatusDto(no, nurse.getName(), "NURSE", status);
            }

            // 사용자 정보가 없을 경우 Unknown 처리
            return new UserWithStatusDto(no, "Unknown", "UNKNOWN", status);
        }).collect(Collectors.toList());
    }
    
    // 전체 직원 리스트를 DB에서 조회
    public List<UserWithStatusDto> searchemployeeall() {
        List<UserWithStatusDto> allEmployees = new ArrayList<>();

        // 의사 리스트 조회
        List<DoctorEntity> doctors = doctorRepository.findAll();
        for (DoctorEntity doctor : doctors) {
            String status = (String)redisTemplate.opsForValue().get(STATUS_KEY_PREFIX + doctor.getNo());
            allEmployees.add(new UserWithStatusDto(doctor.getNo(), doctor.getName(), "DOCTOR", status != null ? status : "미확인"));
        }

        // 간호사 리스트 조회
        List<NurseEntity> nurses = nurseRepository.findAll();
        for (NurseEntity nurse : nurses) {
            String status = (String)redisTemplate.opsForValue().get(STATUS_KEY_PREFIX + nurse.getNo());
            allEmployees.add(new UserWithStatusDto(nurse.getNo(), nurse.getName(), "NURSE", status != null ? status : "미확인"));
        }

        return allEmployees;
    }

    /**
     * 특정 사용자의 상태를 업데이트.
     * @param no 사용자 ID
     * @param status 업데이트할 상태 값
     */
    public void updateStatus(int no, String status) {
        // 사용자 ID에 해당하는 상태를 Redis에 저장 (키: "user_status:<사용자ID>")
    	  System.out.println("Updating status in Redis: " + status);  // 디버깅용 로그
    	    redisTemplate.opsForValue().set(STATUS_KEY_PREFIX + no, status);
    	    System.out.println("Status updated in Redis for user: " + no);  // 디버깅용 로그
    }

    /**
     * 특정 사용자의 상태를 조회.
     * @param no 사용자 ID
     * @return String - 해당 사용자의 상태 값
     */
    public String getStatus(int no) {
        // Redis에서 사용자 ID에 해당하는 상태를 조회
        return (String)redisTemplate.opsForValue().get(STATUS_KEY_PREFIX + no);
    }

    /**
     * 모든 사용자의 상태 정보를 조회 (예: 대시보드 등에서 활용).
     * @return Map<String, String> - 사용자 ID와 상태 값이 매핑된 맵
     */
    public Map<String, Object> getAllStatuses() {
        // Redis에서 모든 사용자 상태 키 가져오기
        Set<String> keys = redisTemplate.keys(STATUS_KEY_PREFIX + "*");

        // 각 키에서 접두사를 제거하여 사용자 ID와 상태 값 매핑
        return keys.stream().collect(Collectors.toMap(
            key -> key.replace(STATUS_KEY_PREFIX, ""),
            key -> redisTemplate.opsForValue().get(key)
        ));
    }
    

    public void cacheUserData(UserWithStatusDto user) {
    	redisTemplate.opsForHash().put("USER_DATA", user.getNo(), user.getName());
        // 로그 추가
        System.out.println("Cached user data: " + user.getNo() + " -> " + user.getName());
    }

    // 사용자 정보를 저장하거나 업데이트할 때 이 메소드를 호출합니다.
    
    public String getUserNameByNo(Integer userNo) {
        // Redis에서 이름을 먼저 조회
        String name = (String) redisTemplate.opsForHash().get("USER_DATA", userNo);

        if (name == null) {
            // Redis에 없는 경우 DB에서 조회
            Optional<DoctorEntity> doctorOpt = doctorRepository.findById(userNo);
            Optional<NurseEntity> nurseOpt = nurseRepository.findById(userNo);

            if (doctorOpt.isPresent()) {
                name = doctorOpt.get().getName();
            } else if (nurseOpt.isPresent()) {
                name = nurseOpt.get().getName();
            } else {
                name = "Unknown User";
            }

            // 조회한 이름을 Redis에 저장
            redisTemplate.opsForHash().put("USER_DATA", userNo, name);
        }

        return name;
    }


}

// 이 클래스는 Redis를 사용해 사용자 상태(예: 온라인, 오프라인)를 관리합니다.
// RedisTemplate을 사용하여 Redis와 상호작용하며, 각 사용자의 상태는 고유한 키(user_status:<userId> 형식)로 관리됩니다.
