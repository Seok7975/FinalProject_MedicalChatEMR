package com.emr.www.repository.chat;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.emr.www.entity.chat.ChatMessageEntity;

import java.util.List;

@Repository
public interface ChatMessageRepository extends JpaRepository<ChatMessageEntity, Long> {
	
	// 발신자와 수신자 간의 메시지를 시간 순으로 조회
	@Query("SELECT m FROM ChatMessageEntity m WHERE m.senderNo = :senderNo AND m.recipientNo = :recipientNo AND m.senderType = :senderType AND m.recipientType = :recipientType ORDER BY m.timestamp ASC")
    List<ChatMessageEntity> findMessages(
        @Param("senderNo") Integer senderNo,
        @Param("senderType") String senderType,
        @Param("recipientNo") Integer recipientNo,
        @Param("recipientType") String recipientType
    );
    
    // 특정 수신자에 대한 읽지 않은 메시지 조회
    List<ChatMessageEntity> findByRecipientNoAndRecipientTypeAndIsReadFalse(
        Integer recipientNo, String recipientType);
	}


