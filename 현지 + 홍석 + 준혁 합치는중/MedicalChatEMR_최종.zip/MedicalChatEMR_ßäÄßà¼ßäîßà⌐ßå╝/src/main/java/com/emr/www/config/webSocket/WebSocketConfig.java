package com.emr.www.config.webSocket;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;
import org.springframework.web.socket.server.HandshakeInterceptor;

import com.emr.www.util.jwt.JwtTokenUtil;

import jakarta.servlet.http.HttpServletRequest;
import java.util.Map;

@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
    	config.enableSimpleBroker("/topic","/queue");
        config.setApplicationDestinationPrefixes("/app");
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        System.out.println("WebSocketConfig: Registering Stomp Endpoints");
        registry.addEndpoint("/ws")
            .setAllowedOriginPatterns("*") 
            .addInterceptors(new HandshakeInterceptor() {
                @Override
                public boolean beforeHandshake(ServerHttpRequest request, ServerHttpResponse response,
                                               WebSocketHandler wsHandler, Map<String, Object> attributes) throws Exception {
                    
                	if (request instanceof ServletServerHttpRequest) {
                        HttpServletRequest servletRequest = ((ServletServerHttpRequest) request).getServletRequest();
                        String token = jwtTokenUtil.resolveToken(servletRequest);

                        if (token != null && jwtTokenUtil.validateToken(token)) {
                        	// 토큰에서 사용자 주키(no)와 역할(role)을 추출하여 WebSocket 세션에 저장
                            Integer userNo = jwtTokenUtil.extractNo(token);
                            String role = jwtTokenUtil.extractRole(token); // 역할(role)을 추출하는 메서드

                            attributes.put("no", userNo != null ? userNo : -1); // 기본값 설정
                            attributes.put("role", role != null ? role : "UNKNOWN"); // 역할이 없으면 기본값 설정

                            // HttpSession에도 저장
                            servletRequest.getSession().setAttribute("userNo", userNo);
                            servletRequest.getSession().setAttribute("role", role);

                            System.out.println("WebSocket Handshake Success for userNo: " + userNo + " and role: " + role); // 핸드셰이크 성공 로그
                            System.out.println("JWT Token: " + token);
                            System.out.println("Extracted User No: " + userNo);
                            System.out.println("Session Attributes Before Handshake: " + attributes);

                            return true;
                        } else {
                            System.out.println("WebSocket Handshake Failed: Invalid Token");
                        }
                    }
                    System.out.println("WebSocket Handshake Failed: Not a ServletServerHttpRequest");
                    return false;
                }

                @Override
                public void afterHandshake(ServerHttpRequest request, ServerHttpResponse response,
                                           WebSocketHandler wsHandler, Exception ex) {
                    // Handshake 이후 추가 처리 (필요 시)
                }
            })
            .withSockJS();
    }
}
