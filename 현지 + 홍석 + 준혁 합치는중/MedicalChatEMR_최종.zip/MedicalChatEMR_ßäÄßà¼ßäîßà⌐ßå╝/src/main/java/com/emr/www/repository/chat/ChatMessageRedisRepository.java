package com.emr.www.repository.chat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;
import com.emr.www.entity.chat.ChatMessageEntity;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Repository
public class ChatMessageRedisRepository {

    private static final String CHAT_MESSAGE_KEY = "CHAT_MESSAGE";

    @Autowired
    private RedisTemplate<String, ChatMessageEntity> redisTemplate;

    public void save(ChatMessageEntity chatMessage) {
        redisTemplate.opsForList().rightPush(CHAT_MESSAGE_KEY, chatMessage);
        redisTemplate.expire(CHAT_MESSAGE_KEY, 1, TimeUnit.DAYS); // 1일 동안 저장
    }

    public List<ChatMessageEntity> findAll() {
        return redisTemplate.opsForList().range(CHAT_MESSAGE_KEY, 0, -1);
    }

    public void deleteAll() {
        redisTemplate.delete(CHAT_MESSAGE_KEY);
    }
}
