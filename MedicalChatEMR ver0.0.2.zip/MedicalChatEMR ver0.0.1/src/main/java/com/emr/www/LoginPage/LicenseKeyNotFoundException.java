package com.emr.www.LoginPage;

public class LicenseKeyNotFoundException extends RuntimeException {
    public LicenseKeyNotFoundException(String message) {
        super(message);
    }
}
